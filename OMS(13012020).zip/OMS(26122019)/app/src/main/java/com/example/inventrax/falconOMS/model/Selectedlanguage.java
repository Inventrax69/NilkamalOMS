package com.example.inventrax.falconOMS.model;

/**
 * Created by Padmaja Rani B on 02/08/2016.
 */
public class Selectedlanguage {
    static int Language;

    public static int getLanguage() {
        return Language;
    }

    public static void setLanguage(int language) {
        Language = language;
    }
}
