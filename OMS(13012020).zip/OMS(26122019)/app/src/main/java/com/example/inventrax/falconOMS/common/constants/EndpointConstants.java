package com.example.inventrax.falconOMS.common.constants;

/**
 * Created by Padmaja.B on 05/31/2018.
 */

public enum EndpointConstants {
    None, LoginDTO, LoginUserDTO, ProfileDTO, Inventory, Exception, ItemMaster_FPS_DTO,
    Customer_FPS_DTO, ProductCatalog_FPS_DTO, OrderAssistance_DTO,HHTCartDTO,OrderFulfilment_DTO,
    Schemes_Discounts_DTO, Scalar, SOHeader_DTO,MiscDTO,CreditLimitCommitment_DTO;
}