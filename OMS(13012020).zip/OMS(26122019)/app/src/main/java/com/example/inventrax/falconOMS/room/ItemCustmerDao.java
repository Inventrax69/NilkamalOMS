package com.example.inventrax.falconOMS.room;

import android.arch.persistence.room.Dao;

@Dao
public abstract class ItemCustmerDao {

    

}
