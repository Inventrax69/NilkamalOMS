
package com.example.inventrax.falconOMS.services;

/**
 * Author   : Padmaja Rani B.
 * Date		: 04/07/2019
 * Purpose	: Web Service URL's and Web Methods
 */


public interface ServiceURLConstants {


    /*
    * To check application connectivity
    * */
    String METHOD_CHECK_INTERNET="checkInternetConnectivity";







}
