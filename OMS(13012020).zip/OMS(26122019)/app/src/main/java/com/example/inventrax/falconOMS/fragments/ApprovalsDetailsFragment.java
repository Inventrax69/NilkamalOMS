package com.example.inventrax.falconOMS.fragments;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.inventrax.falconOMS.R;
import com.example.inventrax.falconOMS.adapters.RefDetailsAdapter;
import com.example.inventrax.falconOMS.common.Common;
import com.example.inventrax.falconOMS.common.constants.EndpointConstants;
import com.example.inventrax.falconOMS.common.constants.ErrorMessages;
import com.example.inventrax.falconOMS.interfaces.ApiInterface;
import com.example.inventrax.falconOMS.model.KeyValues;
import com.example.inventrax.falconOMS.pojos.ApprovalListDTO;
import com.example.inventrax.falconOMS.pojos.CartHeaderListDTO;
import com.example.inventrax.falconOMS.pojos.OMSCoreMessage;
import com.example.inventrax.falconOMS.pojos.OMSExceptionMessage;
import com.example.inventrax.falconOMS.services.RestService;
import com.example.inventrax.falconOMS.util.DialogUtils;
import com.example.inventrax.falconOMS.util.ExceptionLoggerUtils;
import com.example.inventrax.falconOMS.util.MaterialDialogUtils;
import com.example.inventrax.falconOMS.util.ProgressDialogUtils;
import com.example.inventrax.falconOMS.util.SnackbarUtils;
import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;

import org.json.JSONArray;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ApprovalsDetailsFragment extends Fragment implements View.OnClickListener {

    private static final String classCode = "OMS_Android_ApprovalsDetailsFragment";
    private View rootView;
    RecyclerView recyclerView;
    Common common;
    private OMSCoreMessage core;
    RestService restService;
    ErrorMessages errorMessages;
    LinearLayoutManager layoutManager;
    TextView txtCRef, txtCCode, txtCName, txtAccept, txtReject;
    String type;
    EditText etRemarks;
    CartHeaderListDTO cartHeaderListDTO;
    List<ApprovalListDTO> approvalListDTOS;
    String userId, userRoleName;
    boolean isChanged = false;
    String cartHeaderId = "";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.approvals_details_fragment, container, false);

        try {
            loadFormControls();
        } catch (Exception ex) {
            //
        }

        return rootView;
    }

    private void loadFormControls() {

        cartHeaderListDTO = new CartHeaderListDTO();
        int pos = 0;
        if (getArguments().getSerializable("cartHeaderListDTO") != null) {
            cartHeaderListDTO = (CartHeaderListDTO) getArguments().getSerializable("cartHeaderListDTO");
            pos = getArguments().getInt("pos");
        }

        if (getArguments().getString("type") != null) {
            type = getArguments().getString("type");
        }

        if (getArguments().getString("cartHeaderId") != null) {
            cartHeaderId = getArguments().getString("cartHeaderId");
        }

        SharedPreferences sp = getActivity().getSharedPreferences(KeyValues.MY_PREFS, Context.MODE_PRIVATE);
        userId = sp.getString(KeyValues.USER_ID, "");
        userRoleName = sp.getString(KeyValues.USER_ROLE_NAME, "");

        common = new Common();
        restService = new RestService();
        core = new OMSCoreMessage();
        errorMessages = new ErrorMessages();

        recyclerView = rootView.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        txtCRef = (TextView) rootView.findViewById(R.id.txtCRef);
        txtCCode = (TextView) rootView.findViewById(R.id.txtCCode);
        txtCName = (TextView) rootView.findViewById(R.id.txtCName);
        txtAccept = (TextView) rootView.findViewById(R.id.txtAccept);
        txtReject = (TextView) rootView.findViewById(R.id.txtReject);

        etRemarks = (EditText) rootView.findViewById(R.id.etRemarks);

        txtAccept.setOnClickListener(this);
        txtReject.setOnClickListener(this);

        if (cartHeaderId.equals("")) {
            ApprovelItemList(cartHeaderListDTO.getCartHeaderID() + "|" + type);
        } else {
            ApprovelItemList(cartHeaderId + "|" + type);
        }

    }

    AlertDialog alert;

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.txtAccept:

                if (etRemarks.getText().toString().isEmpty()) {
                    SnackbarUtils.showSnackbarLengthShort((CoordinatorLayout) ((Activity) getActivity()).findViewById(R.id.snack_bar_action_layout), "Please write remarks", ContextCompat.getColor(getActivity(), R.color.dark_red), Snackbar.LENGTH_SHORT);
                    return;
                }

                final AlertDialog.Builder builder;

                builder = new AlertDialog.Builder(getActivity());

                 // Setting message manually and performing action on button click
                 builder.setMessage("Are you sure to Accept")
                        .setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                if (approvalListDTOS.size() > 0) {
                                    if (isChanged) {
                                        UpdateApprovalCartList();
                                    } else {
                                        ApproveWorkflow(approvalListDTOS.get(0), "4");
                                    }
                                } else {
                                    SnackbarUtils.showSnackbarLengthShort((CoordinatorLayout) ((Activity) getActivity()).findViewById(R.id.snack_bar_action_layout), "No items available", ContextCompat.getColor(getActivity(), R.color.dark_red), Snackbar.LENGTH_SHORT);
                                }
                            }
                        })
                        .setNegativeButton("CLOSE", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                alert.dismiss();
                            }
                        });

                //Creating dialog box
                alert = builder.create();
                //Setting the title manually
                alert.setTitle("Alert");
                alert.show();


                break;

            case R.id.txtReject:

                if (etRemarks.getText().toString().isEmpty()) {
                    SnackbarUtils.showSnackbarLengthShort((CoordinatorLayout) ((Activity) getActivity()).findViewById(R.id.snack_bar_action_layout), "Please write remarks", ContextCompat.getColor(getActivity(), R.color.dark_red), Snackbar.LENGTH_SHORT);
                    return;
                }

                final AlertDialog.Builder builder1;

                builder1 = new AlertDialog.Builder(getActivity());

                //Setting message manually and performing action on button click
                builder1.setMessage("Are you sure to Reject")
                        .setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                if (approvalListDTOS.size() > 0) {
                                    ApproveWorkflow(approvalListDTOS.get(0), "2");
                                } else {
                                    SnackbarUtils.showSnackbarLengthShort((CoordinatorLayout) ((Activity) getActivity()).findViewById(R.id.snack_bar_action_layout), "No items available", ContextCompat.getColor(getActivity(), R.color.dark_red), Snackbar.LENGTH_SHORT);
                                }

                            }
                        })
                        .setNegativeButton("CLOSE", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                alert.dismiss();
                            }
                        });

                //Creating dialog box
                alert = builder1.create();
                //Setting the title manually
                alert.setTitle("Alert");
                alert.show();

                break;

        }

    }


    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle(R.string.toolbar_approvals_details);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayUseLogoEnabled(false);
    }

    public void ApprovelItemList(final String enitity_object) {

        OMSCoreMessage message = new OMSCoreMessage();
        message = common.SetAuthentication(EndpointConstants.Scalar, getActivity());
        message.setEntityObject(enitity_object);

        Call<OMSCoreMessage> call = null;
        ApiInterface apiService = RestService.getClient().create(ApiInterface.class);

        ProgressDialogUtils.showProgressDialog("Please wait..");

        call = apiService.ApprovelItemList(message);

        try {
            //Getting response from the method
            call.enqueue(new Callback<OMSCoreMessage>() {

                @Override
                public void onResponse(Call<OMSCoreMessage> call, Response<OMSCoreMessage> response) {

                    if (response.body() != null) {

                        core = response.body();

                        if ((core.getType().toString().equals("Exception"))) {

                            OMSExceptionMessage omsExceptionMessage = null;

                            for (OMSExceptionMessage oms : core.getOMSMessages()) {
                                omsExceptionMessage = oms;
                                ProgressDialogUtils.closeProgressDialog();
                                common.showAlertType(omsExceptionMessage, getActivity(), getActivity());
                            }
                            ProgressDialogUtils.closeProgressDialog();

                        } else {
                            ProgressDialogUtils.closeProgressDialog();

                            try {
                                approvalListDTOS = new ArrayList<>();

                                if (core.getEntityObject().equals("No Records Found")) {
                                    SnackbarUtils.showSnackbarLengthShort((CoordinatorLayout) ((Activity) getActivity()).findViewById(R.id.snack_bar_action_layout), "No Records Found", ContextCompat.getColor(getActivity(), R.color.dark_red), Snackbar.LENGTH_SHORT);
                                    return;
                                }

                                txtCRef.setText((String) ((LinkedTreeMap) core.getEntityObject()).get("CartRefNo"));
                                txtCCode.setText((String) ((LinkedTreeMap) core.getEntityObject()).get("PartnerCode"));
                                txtCName.setText((String) ((LinkedTreeMap) core.getEntityObject()).get("PartnerName"));

                                JSONArray getApprovalItemList = new JSONArray((ArrayList) ((LinkedTreeMap) core.getEntityObject()).get("AppprovalList"));
                                ApprovalListDTO approvalListDTO = new ApprovalListDTO();
                                for (int i = 0; i < getApprovalItemList.length(); i++) {
                                    approvalListDTO = new Gson().fromJson(getApprovalItemList.getJSONObject(i).toString(), ApprovalListDTO.class);
                                    approvalListDTOS.add(approvalListDTO);
                                }

                                RefDetailsAdapter refListAdapter = new RefDetailsAdapter(getActivity(), approvalListDTOS, type, new RefDetailsAdapter.OnItemClickListener() {
                                    @Override
                                    public void onItemClick(int pos) {
                                        //
                                    }
                                }, new RefDetailsAdapter.OnApprovalUpdate() {
                                    @Override
                                    public void onApprovalUpdate(List<ApprovalListDTO> approvalListDTOS1) {
                                        isChanged = true;
                                        approvalListDTOS = approvalListDTOS1;
                                    }
                                });

                                recyclerView.setAdapter(refListAdapter);

                            } catch (Exception ex) {
                                ProgressDialogUtils.closeProgressDialog();
                                SnackbarUtils.showSnackbarLengthShort((CoordinatorLayout) ((Activity) getActivity()).findViewById(R.id.snack_bar_action_layout), "Error while getting list of materials", ContextCompat.getColor(getActivity(), R.color.dark_red), Snackbar.LENGTH_SHORT);
                            }
                        }
                    }
                }

                // response object fails
                @Override
                public void onFailure(Call<OMSCoreMessage> call, Throwable throwable) {
                    DialogUtils.showAlertDialog(getActivity(), errorMessages.EMC_0002);
                    ProgressDialogUtils.closeProgressDialog();
                }
            });
        } catch (Exception ex) {
            try {
                ExceptionLoggerUtils.createExceptionLog(ex.toString(), classCode, "001", getActivity());
            } catch (IOException e) {
                e.printStackTrace();
            }
            ProgressDialogUtils.closeProgressDialog();
            DialogUtils.showAlertDialog(getActivity(), errorMessages.EMC_0003);
        }
    }

    public void UpdateApprovalCartList() {

        OMSCoreMessage message = new OMSCoreMessage();
        message = common.SetAuthentication(EndpointConstants.Scalar, getActivity());
        message.setEntityObject(new Gson().toJson(approvalListDTOS));

        Call<OMSCoreMessage> call = null;
        ApiInterface apiService =
                RestService.getClient().create(ApiInterface.class);

        ProgressDialogUtils.showProgressDialog("Please wait..");

        call = apiService.UpdateApprovalCartList(message);

        try {
            //Getting response from the method
            call.enqueue(new Callback<OMSCoreMessage>() {

                @Override
                public void onResponse(Call<OMSCoreMessage> call, Response<OMSCoreMessage> response) {

                    if (response.body() != null) {

                        core = response.body();

                        if ((core.getType().toString().equals("Exception"))) {

                            OMSExceptionMessage omsExceptionMessage = null;

                            for (OMSExceptionMessage oms : core.getOMSMessages()) {
                                omsExceptionMessage = oms;
                                ProgressDialogUtils.closeProgressDialog();
                                common.showAlertType(omsExceptionMessage, getActivity(), getActivity());
                            }
                            ProgressDialogUtils.closeProgressDialog();

                        } else {
                            ProgressDialogUtils.closeProgressDialog();

                            try {

                                if (core.getEntityObject().equals("success")) {
                                    isChanged = false;
                                    ApproveWorkflow(approvalListDTOS.get(0), "4");
                                    RefDetailsAdapter refListAdapter = new RefDetailsAdapter(getActivity(), approvalListDTOS, type, new RefDetailsAdapter.OnItemClickListener() {
                                        @Override
                                        public void onItemClick(int pos) {
                                            //
                                        }
                                    }, new RefDetailsAdapter.OnApprovalUpdate() {
                                        @Override
                                        public void onApprovalUpdate(List<ApprovalListDTO> approvalListDTOS1) {
                                            isChanged = true;
                                            approvalListDTOS = approvalListDTOS1;
                                        }
                                    });

                                    recyclerView.setAdapter(refListAdapter);
                                } else {
                                    Toast.makeText(getActivity(), "Failed to update", Toast.LENGTH_SHORT).show();
                                }
                                ///
                            } catch (Exception ex) {
                                ProgressDialogUtils.closeProgressDialog();
                                Toast.makeText(getActivity(), ex.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }

                // response object fails
                @Override
                public void onFailure(Call<OMSCoreMessage> call, Throwable throwable) {
                    DialogUtils.showAlertDialog(getActivity(), errorMessages.EMC_0002);
                    ProgressDialogUtils.closeProgressDialog();
                }
            });
        } catch (Exception ex) {
            try {
                ExceptionLoggerUtils.createExceptionLog(ex.toString(), classCode, "001", getActivity());
            } catch (IOException e) {
                e.printStackTrace();
            }
            ProgressDialogUtils.closeProgressDialog();
            DialogUtils.showAlertDialog(getActivity(), errorMessages.EMC_0003);
        }
    }

    public void ApproveWorkflow(ApprovalListDTO approvalListDTO, String Status) {

        OMSCoreMessage message = new OMSCoreMessage();
        message = common.SetAuthentication(EndpointConstants.Scalar, getActivity());
        ApprovalListDTO approvalListDTO1 = new ApprovalListDTO();
        approvalListDTO1.setWorkFlowtransactionID(approvalListDTO.getWorkFlowtransactionID());
        approvalListDTO1.setCartHeaderID(approvalListDTO.getCartHeaderID());
        approvalListDTO1.setWorkFlowTypeID(approvalListDTO.getWorkFlowTypeId());
        approvalListDTO1.setStatusID(Status);
        approvalListDTO1.setRemarks(etRemarks.getText().toString());
        approvalListDTO1.setUserRoleID(approvalListDTO.getUserRoleId());
        message.setEntityObject(approvalListDTO1);

        Call<OMSCoreMessage> call = null;
        ApiInterface apiService = RestService.getClient().create(ApiInterface.class);

        ProgressDialogUtils.showProgressDialog("Please wait..");

        call = apiService.ApproveWorkflow(message);

        try {
            //Getting response from the method
            call.enqueue(new Callback<OMSCoreMessage>() {

                @Override
                public void onResponse(Call<OMSCoreMessage> call, Response<OMSCoreMessage> response) {

                    if (response.body() != null) {

                        core = response.body();

                        if ((core.getType().toString().equals("Exception"))) {

                            OMSExceptionMessage omsExceptionMessage = null;

                            for (OMSExceptionMessage oms : core.getOMSMessages()) {
                                omsExceptionMessage = oms;
                                ProgressDialogUtils.closeProgressDialog();
                                common.showAlertType(omsExceptionMessage, getActivity(), getActivity());
                            }
                            ProgressDialogUtils.closeProgressDialog();

                        } else {
                            ProgressDialogUtils.closeProgressDialog();
                            try {
                                MaterialDialogUtils.showUploadSuccessDialog(getActivity(),"Successfully");
                                ((Activity) getActivity()).onBackPressed();
                                /*   Bundle bundle=new Bundle();
                                bundle.putString("type",type);
                                FragmentUtils.replaceFragmentWithBackStackWithBundle(getActivity(), R.id.container, new ApprovalsListFragment(),bundle);*/
                            } catch (Exception ex) {
                                ProgressDialogUtils.closeProgressDialog();
                                Toast.makeText(getActivity(), ex.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }

                // response object fails
                @Override
                public void onFailure(Call<OMSCoreMessage> call, Throwable throwable) {
                    DialogUtils.showAlertDialog(getActivity(), errorMessages.EMC_0002);
                    ProgressDialogUtils.closeProgressDialog();
                }
            });
        } catch (Exception ex) {
            try {
                ExceptionLoggerUtils.createExceptionLog(ex.toString(), classCode, "001", getActivity());
            } catch (IOException e) {
                e.printStackTrace();
            }
            ProgressDialogUtils.closeProgressDialog();
            DialogUtils.showAlertDialog(getActivity(), errorMessages.EMC_0003);
        }
    }
}
