package com.example.inventrax.falconOMS.activities;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.internal.BottomNavigationItemView;
import android.support.design.internal.BottomNavigationMenuView;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.TextView;
import android.widget.Toast;

import com.example.inventrax.falconOMS.R;
import com.example.inventrax.falconOMS.common.Common;
import com.example.inventrax.falconOMS.common.constants.EndpointConstants;
import com.example.inventrax.falconOMS.common.constants.ErrorMessages;
import com.example.inventrax.falconOMS.fragments.HomeFragmentHints;
import com.example.inventrax.falconOMS.fragments.NotificationFragment;
import com.example.inventrax.falconOMS.fragments.ProductCatalogFragment;
import com.example.inventrax.falconOMS.fragments.ProfileFragment;
import com.example.inventrax.falconOMS.fragments.SearchFragment;
import com.example.inventrax.falconOMS.interfaces.ApiInterface;
import com.example.inventrax.falconOMS.logout.LogoutUtil;
import com.example.inventrax.falconOMS.model.KeyValues;
import com.example.inventrax.falconOMS.pojos.CartDetailsListDTO;
import com.example.inventrax.falconOMS.pojos.CartHeaderListDTO;
import com.example.inventrax.falconOMS.pojos.CustomerListDTO;
import com.example.inventrax.falconOMS.pojos.ItemListResponse;
import com.example.inventrax.falconOMS.pojos.OMSCoreMessage;
import com.example.inventrax.falconOMS.pojos.OMSExceptionMessage;
import com.example.inventrax.falconOMS.pojos.productCatalogs;
import com.example.inventrax.falconOMS.room.AppDatabase;
import com.example.inventrax.falconOMS.room.CartDetails;
import com.example.inventrax.falconOMS.room.CartHeader;
import com.example.inventrax.falconOMS.room.CustomerTable;
import com.example.inventrax.falconOMS.room.ItemTable;
import com.example.inventrax.falconOMS.room.RoomAppDatabase;
import com.example.inventrax.falconOMS.services.RestService;
import com.example.inventrax.falconOMS.util.DialogUtils;
import com.example.inventrax.falconOMS.util.ExceptionLoggerUtils;
import com.example.inventrax.falconOMS.util.FragmentUtils;
import com.example.inventrax.falconOMS.util.NetworkUtils;
import com.example.inventrax.falconOMS.util.ProgressDialogUtils;
import com.example.inventrax.falconOMS.util.SharedPreferencesUtils;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.support.design.bottomnavigation.LabelVisibilityMode.LABEL_VISIBILITY_LABELED;


public class MainActivity extends AppCompatActivity {

    private static final String classCode = "OMS_Android_MainActivity";
    private TextView mTextMessage, txtTimer;
    Toolbar toolbar;
    ActionBar actionBar;
    BottomNavigationView navigation;
    private CoordinatorLayout coordinatorLayout;
    private LogoutUtil logoutUtil;
    SharedPreferencesUtils sharedPreferencesUtils;
    ErrorMessages errorMessages;
    Common common;
    private OMSCoreMessage core;
    private ProgressDialogUtils progressDialogUtils;
    RestService restService;
    private List<ItemListResponse> lstItem;
    private List<CustomerListDTO> customerList;
    List<ItemTable> itemTables;
    List<CustomerTable> customerTables;
    List<CartDetails> cartDetails;
    List<productCatalogs> cartList = null;
    AppDatabase db;
    String userName = "", userId = "", cartHeaderId = "";
    private String itemTimeStamp = "", customerTimeStamp = "";
    private static CountDownTimer countDownTimer;
    int c_width, c_height;
    boolean doubleBackToExitPressedOnce = false;

    LocationManager mlocManager;
    LocationListener locListener;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            switch (item.getItemId()) {

                case R.id.navigation_home:
                    getSupportActionBar().setDisplayHomeAsUpEnabled(false);
                    FragmentManager fm = getSupportFragmentManager();
                    for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                        fm.popBackStack();
                    }
                    loadFragment(new HomeFragmentHints());
                    return true;

                /*case R.id.navigation_schemes:
                    loadFragment(new CustomerListFragment());
                    return true;*/

                case R.id.navigation_cart:
                    if (db.userDivisionCustDAO().getUserDivisionCustCount() > 0) {
                        Intent i = new Intent(MainActivity.this, CartActivity.class);
                        startActivity(i);
                    }
                    return true;

                case R.id.navigation_search:
                    loadFragment(new SearchFragment());
                    return true;

                case R.id.navigation_more:
                    loadFragment(new ProfileFragment());
                    return true;

            }
            return false;
        }
    };

/*
    public void getCurrentLocation() {
        if (mlocManager != null) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            locListener=new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {

                }

                @Override
                public void onStatusChanged(String s, int i, Bundle bundle) {

                }

                @Override
                public void onProviderEnabled(String s) {

                }

                @Override
                public void onProviderDisabled(String s) {

                }
            };
            mlocManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locListener);
            if (mlocManager != null) {
               Location location = mlocManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (location != null) {
                    double latitude = location.getLatitude();
                    double longitude = location.getLongitude();
                }
            }
            // mlocManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locListener );
        }

    }*/

    Animation anim;
    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

/*        mlocManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);

        getCurrentLocation();*/

        FirebaseMessaging.getInstance().subscribeToTopic("all");

        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
        
        toolbar = (Toolbar) findViewById(R.id.toolbar);

        coordinatorLayout = (CoordinatorLayout) findViewById(R.id.snack_bar_action_layout);

        setSupportActionBar(toolbar);

        // gets the tool bar icon and handles click event
        toolbar.setLogo(ContextCompat.getDrawable(MainActivity.this, R.drawable.nilkamal));
        /*View logoView = AndroidUtils.getToolbarLogoIcon(toolbar);
        if (logoView != null)
            logoView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    loadFragment(new ProfileFragment());
                }
            });*/

        // gets the action bar support to enable features
        actionBar = getSupportActionBar();
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        // load the store fragment by default
        loadFragment(new HomeFragmentHints());

        navigation = (BottomNavigationView) findViewById(R.id.navigation);
        BottomNavigationViewHelper.removeShiftMode(navigation);       // removes bottom navigation bar animation
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        logoutUtil = new LogoutUtil();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            Log.i("ddere", "Extra:" + extras.getString("whattodo"));
        }

        db = new RoomAppDatabase(MainActivity.this).getAppDatabase();

        SharedPreferences sp = this.getSharedPreferences(KeyValues.MY_PREFS, Context.MODE_PRIVATE);
        userName = sp.getString(KeyValues.USER_NAME, "");
        userId = sp.getString(KeyValues.USER_ID, "");
        cartHeaderId = sp.getString(KeyValues.CART_HEADERID, "");

        errorMessages = new ErrorMessages();
        common = new Common();
        restService = new RestService();
        core = new OMSCoreMessage();
        progressDialogUtils = new ProgressDialogUtils(MainActivity.this);

        progressDialogUtils = new ProgressDialogUtils(this);

        lstItem = new ArrayList<ItemListResponse>();
        customerList = new ArrayList<CustomerListDTO>();
        cartList = new ArrayList<>();

        txtTimer = (TextView) findViewById(R.id.txtTimer);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        final int height = displayMetrics.heightPixels;
        final int width = displayMetrics.widthPixels;

        txtTimer.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                txtTimer.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                c_width = width - txtTimer.getWidth();
                c_height = height - txtTimer.getHeight();
            }
        });


        txtTimer.setOnTouchListener(new View.OnTouchListener() {

            private float xCoOrdinate, yCoOrdinate;

            public boolean onTouch(View v, MotionEvent event) {
                // TODO Auto-generated method stub
                //drag(event, v);
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        xCoOrdinate = v.getX() - event.getRawX();
                        yCoOrdinate = v.getY() - event.getRawY();
                        break;
                    case MotionEvent.ACTION_MOVE:
                        if (((event.getRawX() + xCoOrdinate) > 0.5 && (event.getRawX() + xCoOrdinate) < c_width))
                            if ((event.getRawY() + yCoOrdinate) > 0.5 && (event.getRawY() + yCoOrdinate) < c_height)
                                v.animate().x(event.getRawX() + xCoOrdinate).y(event.getRawY() + yCoOrdinate).setDuration(0).start();
                        break;
                    default:
                        return false;
                }
                return true;
            }

        });


        sharedPreferencesUtils = new SharedPreferencesUtils(KeyValues.MY_PREFS, getApplicationContext());
        //sharedPreferencesUtils.savePreference(KeyValues.USER_ROLE_NAME, "DTD");
        //sharedPreferencesUtils.savePreference("timer", mills);
        try {
            Calendar calendar = Calendar.getInstance();
            long mills = calendar.getTimeInMillis();
            long timer = sharedPreferencesUtils.loadPreferenceAsLong("timer");
            startTime(300000 - (mills - timer));
        } catch (Exception e) {
            txtTimer.setText("00:00");
            txtTimer.setVisibility(View.GONE);
        }

        anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(500); //You can manage the blinking time with this parameter
        anim.setStartOffset(20);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        anim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                // if you want to change color at start of animation
                //textview.settextcolor("your color")
                txtTimer.setTextColor(Color.RED);
                if (txtTimer.getText().toString().equals("00:00")) {
                    txtTimer.setVisibility(View.GONE);
                    txtTimer.clearAnimation();
                }
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                // if you want to change color at end of animation
                //textview.settextcolor("your color")
                txtTimer.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                if (txtTimer.getText().toString().equals("00:00")) {
                    txtTimer.setVisibility(View.GONE);
                    txtTimer.clearAnimation();
                }
            }
        });



         /* if(sharedPreferencesUtils.loadPreferenceAsBoolean(KeyValues.IS_ITEM_LOADED)){

            String itemLastTime = new SimpleDateFormat(DDMMMYYYYHHMMSS_DATE_FORMAT_SLASH).format(new Date(db.itemDAO().getLastRecord().timestamp));
            String custLastTime = new SimpleDateFormat(DDMMMYYYYHHMMSS_DATE_FORMAT_SLASH).format(new Date(db.customerDAO().getLastRecord().timestamp));
            itemTimeStamp = itemLastTime;
        }*/


        // itemTimeStamp = "2019-08-27 19:08:18.630";

        customerTimeStamp = "2019-08-27 19:08:18.630";

        if (NetworkUtils.isInternetAvailable(MainActivity.this)) {
            //syncItemData();
            // syncCustomerData();
            cartSyncAsync();
        }

        if (getIntent().getExtras() != null) {
            boolean openCatalog = getIntent().getExtras().getBoolean(KeyValues.OPEN_CATALOG);
            if (openCatalog) {
                loadFragment(new ProductCatalogFragment());
            }
        }
    }

    private void loadFragment(Fragment fragment) {
        // load fragment
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }


    public void startTime(final long mills) {

        if (countDownTimer != null) {
            countDownTimer.cancel();
        }

        countDownTimer = new CountDownTimer(mills, 1000) {

            public void onTick(long millisUntilFinished) {
                // shows time and changes for every second
                int seconds = (int) (millisUntilFinished / 1000);
                int minutes = seconds / 60;
                seconds = seconds % 60;
                txtTimer.setVisibility(View.VISIBLE);
                txtTimer.setText(String.format("%02d", minutes) + ":" + String.format("%02d", seconds));
                if (minutes == 0)
                    txtTimer.startAnimation(anim);
            }

            public void onFinish() {
                // Called after timer finishes
                txtTimer.setText("00:00");
                txtTimer.setVisibility(View.GONE);
                if (mills > 0)
                    deleteCartItemReservation();
                //deleteCartItemReservation();
            }
        }.start();

    }

    // to show or hide bottom navigation bar from different fragments
    public void SetNavigationVisibility(boolean b) {
        if (b) {
            navigation.setVisibility(View.VISIBLE);
        } else {
            navigation.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case R.id.action_logout: {
                logoutUtil.doLogout(MainActivity.this, MainActivity.this);
            }
            break;

            /*
            case R.id.action_about: {
                //FragmentUtils.replaceFragmentWithBackStack(this, R.id.container_body, new AboutFragment());
            }
            break;
            */
            case R.id.action_profile: {
                FragmentUtils.replaceFragmentWithBackStack(this, R.id.container, new ProfileFragment());
            }
            break;

            case R.id.action_notification: {
                FragmentUtils.replaceFragmentWithBackStack(this, R.id.container, new NotificationFragment());
                //Toast.makeText(MainActivity.this, "Notifications pressed", Toast.LENGTH_SHORT).show();
            }
            break;

            case R.id.action_cart: {
                if (db.userDivisionCustDAO().getUserDivisionCustCount() > 0) {
                    Intent i = new Intent(MainActivity.this, CartActivity.class);
                    startActivity(i);
                }
            }
            break;

            case android.R.id.home: {
                getSupportActionBar().setDisplayHomeAsUpEnabled(false);
                onBackPressed();
            }
            break;

            case R.id.action_home: {
                getSupportActionBar().setDisplayHomeAsUpEnabled(false);
                FragmentManager fm = getSupportFragmentManager();
                for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                    fm.popBackStack();
                }
                loadFragment(new HomeFragmentHints());
            }
            break;
        }

        return super.onOptionsItemSelected(item);
    }


    public void syncCart() {

        OMSCoreMessage message = new OMSCoreMessage();
        message = common.SetAuthentication(EndpointConstants.ProductCatalog_FPS_DTO, MainActivity.this);
        productCatalogs productCatalogs = new productCatalogs();
        productCatalogs.setHandheldRequest(true);
        productCatalogs.setUserID(userId);
        message.setEntityObject(productCatalogs);

        Call<OMSCoreMessage> call = null;
        ApiInterface apiService = RestService.getClient().create(ApiInterface.class);
        ProgressDialogUtils.showProgressDialog("Please Wait");

        call = apiService.cartlist(message);

        final String sMessage = message.getEntityObject().toString();

        try {
            //Getting response from the method
            call.enqueue(new Callback<OMSCoreMessage>() {

                @Override
                public void onResponse(Call<OMSCoreMessage> call, Response<OMSCoreMessage> response) {
                    ProgressDialogUtils.closeProgressDialog();
                    if (response.body() != null) {

                        core = response.body();

                        if ((core.getType().toString().equals("Exception"))) {

                            OMSExceptionMessage omsExceptionMessage = null;

                            for (OMSExceptionMessage oms : core.getOMSMessages()) {

                                omsExceptionMessage = oms;
                                ProgressDialogUtils.closeProgressDialog();
                                common.showAlertType(omsExceptionMessage, MainActivity.this, MainActivity.this);
                            }


                        } else {

                            ProgressDialogUtils.closeProgressDialog();

                            try {

                                if (core.getEntityObject().toString().equals(sMessage)) {
                                    Toast.makeText(MainActivity.this, "Error Response", Toast.LENGTH_SHORT).show();
                                    return;
                                }

                                JSONArray getCartHeader = new JSONArray((String) core.getEntityObject());

                                /*
                                db.cartHeaderDAO().deleteAllIsUpdated();
                                db.cartDetailsDAO().deleteAllIsUpdated();
                                db.cartHeaderDAO().deleteHeadersNotThereInCartDetails();
                                */

                                db.cartHeaderDAO().deleteAll();
                                db.cartDetailsDAO().deleteAll();

                                for (int i = 0; i < getCartHeader.length(); i++) {

                                    TypeToken<CartHeaderListDTO> header = new TypeToken<CartHeaderListDTO>() { };

                                    for (int j = 0; j < getCartHeader.getJSONObject(i).getJSONArray("CartHeader").length(); j++) {

                                        CartHeaderListDTO cartHeaderListDTO = new Gson().fromJson(getCartHeader.getJSONObject(i).getJSONArray("CartHeader").getJSONObject(j).toString(), CartHeaderListDTO.class);

                                        db.cartHeaderDAO().insert(new CartHeader(cartHeaderListDTO.getCustomerID(), cartHeaderListDTO.getCustomerName(), cartHeaderListDTO.getCreditLimit(), cartHeaderListDTO.getCartHeaderID(),
                                                cartHeaderListDTO.getIsInActive(), cartHeaderListDTO.getIsCreditLimit(), cartHeaderListDTO.getIsApproved(), 0, cartHeaderListDTO.getCreatedOn(),
                                                cartHeaderListDTO.getTotalPrice(),cartHeaderListDTO.getTotalPriceWithTax()));

                                        for (int k = 0; k < cartHeaderListDTO.getListCartDetailsList().size(); k++) {

                                            CartDetailsListDTO cart = cartHeaderListDTO.getListCartDetailsList().get(k);

                                            db.cartDetailsDAO().insert(new CartDetails(cart.getCartHeaderID(), cart.getMaterialMasterID(),
                                                    cart.getMCode(), cart.getMDescription(), cart.getActualDeliveryDate(),
                                                    cart.getQuantity(), cart.getFileNames(), cart.getPrice(), cart.getIsInActive(),
                                                    cart.getCartDetailsID(), cartHeaderListDTO.getCustomerID(), 0,
                                                    cart.getMaterialPriorityID(),cart.getTotalPrice(),cart.getOfferValue(),cart.getOfferItemCartDetailsID()));
                                        }

                                    }

                                }

                                BottomNavigationMenuView menuView = (BottomNavigationMenuView) navigation.getChildAt(0);
                                BottomNavigationItemView itemView = (BottomNavigationItemView) menuView.getChildAt(1);

                                View notificationBadge = LayoutInflater.from(MainActivity.this).inflate(R.layout.notification_badge, menuView, false);
                                TextView textView = notificationBadge.findViewById(R.id.counter_badge);
                                textView.setText(String.valueOf(db.cartDetailsDAO().getCartDetailsCountIsApproved()));
                                itemView.addView(notificationBadge);

                                ProgressDialogUtils.closeProgressDialog();

                            } catch (Exception e) {
                                ProgressDialogUtils.closeProgressDialog();
                            }
                        }
                    }
                }

                // response object fails
                @Override
                public void onFailure(Call<OMSCoreMessage> call, Throwable throwable) {
                    DialogUtils.showAlertDialog(MainActivity.this, errorMessages.EMC_0002);
                    ProgressDialogUtils.closeProgressDialog();
                }
            });
        } catch (Exception ex) {

            try {
                ExceptionLoggerUtils.createExceptionLog(ex.toString(), classCode, "001", MainActivity.this);

            } catch (IOException e) {
                e.printStackTrace();
            }
            ProgressDialogUtils.closeProgressDialog();
            DialogUtils.showAlertDialog(MainActivity.this, errorMessages.EMC_0003);
        }
    }

    @SuppressLint("ObsoleteSdkInt")
    public void cartSyncAsync() {
        @SuppressLint("StaticFieldLeak") AsyncTask<Void, Void, String> task = new AsyncTask<Void, Void, String>() {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected String doInBackground(Void... params) {

                String msg = "";
                syncCart();
                // addToCart();
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {

            }
        };

        if (Build.VERSION.SDK_INT >= 11/*HONEYCOMB*/) {
            task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            task.execute();
        }
    }


    public void deleteCartItemReservation() {

        OMSCoreMessage message = new OMSCoreMessage();
        message = common.SetAuthentication(EndpointConstants.ProductCatalog_FPS_DTO, MainActivity.this);
        productCatalogs oDto = new productCatalogs();
        oDto.setUserID(userId);

        message.setEntityObject(oDto);

        Call<OMSCoreMessage> call = null;
        ApiInterface apiService =
                RestService.getClient().create(ApiInterface.class);

        call = apiService.DeleteReservation(message);
        ProgressDialogUtils.showProgressDialog("Please Wait");


        try {
            //Getting response from the method
            call.enqueue(new Callback<OMSCoreMessage>() {

                @Override
                public void onResponse(Call<OMSCoreMessage> call, Response<OMSCoreMessage> response) {

                    if (response.body() != null) {

                        core = response.body();

                        if ((core.getType().toString().equals("Exception"))) {

                            OMSExceptionMessage omsExceptionMessage = null;

                            for (OMSExceptionMessage oms : core.getOMSMessages()) {

                                omsExceptionMessage = oms;
                                ProgressDialogUtils.closeProgressDialog();
                                common.showAlertType(omsExceptionMessage, MainActivity.this, MainActivity.this);
                            }

                        } else {

                            try {

                                String respObject = core.getEntityObject().toString();
                                txtTimer.setText("00:00");
                                txtTimer.setVisibility(View.GONE);
                                if (respObject.equals("Reservation Deleted Successfully")) {
                                    db.cartDetailsDAO().resetDeliveryDates();
                                }

                                ProgressDialogUtils.closeProgressDialog();

                            } catch (Exception ex) {
                                ProgressDialogUtils.closeProgressDialog();
                                Toast.makeText(MainActivity.this, ex.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                        ProgressDialogUtils.closeProgressDialog();
                    }
                    ProgressDialogUtils.closeProgressDialog();
                }

                // response object fails
                @Override
                public void onFailure(Call<OMSCoreMessage> call, Throwable throwable) {
                    Toast.makeText(MainActivity.this, throwable.toString(), Toast.LENGTH_LONG).show();
                    ProgressDialogUtils.closeProgressDialog();
                }
            });
        } catch (Exception ex) {

            try {
                ExceptionLoggerUtils.createExceptionLog(ex.toString(), classCode, "001", MainActivity.this);
            } catch (IOException e) {
                e.printStackTrace();
            }
            ProgressDialogUtils.closeProgressDialog();
            DialogUtils.showAlertDialog(MainActivity.this, errorMessages.EMC_0003);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            if (txtTimer.getText().toString().equals("00:00")) {
                txtTimer.setText("00:00");
                txtTimer.setVisibility(View.GONE);
            } else {
                Calendar calendar = Calendar.getInstance();
                long mills = calendar.getTimeInMillis();
                long timer = sharedPreferencesUtils.loadPreferenceAsLong("timer");
                startTime(300000 - (mills - timer));
            }
        } catch (Exception e) {
            //
        }

        BottomNavigationMenuView menuView = (BottomNavigationMenuView) navigation.getChildAt(0);
        BottomNavigationItemView itemView = (BottomNavigationItemView) menuView.getChildAt(1);

        View notificationBadge = LayoutInflater.from(MainActivity.this).inflate(R.layout.notification_badge, menuView, false);
        TextView textView = notificationBadge.findViewById(R.id.counter_badge);
        textView.setText(String.valueOf(db.cartDetailsDAO().getCartDetailsCountIsApproved()));
        itemView.addView(notificationBadge);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {

        if (getSupportFragmentManager().getBackStackEntryCount() > 1) {
            getSupportFragmentManager().popBackStack();
        } else {

            if (doubleBackToExitPressedOnce) {
                Intent homeIntent = new Intent(Intent.ACTION_MAIN);
                homeIntent.addCategory(Intent.CATEGORY_HOME);
                homeIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(homeIntent);
                finish();
                return;
            }

            this.doubleBackToExitPressedOnce = true;
            final Toast toast = Toast.makeText(this, "Please click Back again to exit", Toast.LENGTH_SHORT);
            toast.show();
/*            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    toast.cancel();
                }
            }, 1000);*/

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    doubleBackToExitPressedOnce = false;
                }
            }, 3000);

        }
    }
}

class BottomNavigationViewHelper {

    @SuppressLint("RestrictedApi")
    static void removeShiftMode(BottomNavigationView view) {
        BottomNavigationMenuView menuView = (BottomNavigationMenuView) view.getChildAt(0);
        try {
            Field shiftingMode = menuView.getClass().getDeclaredField("mShiftingMode");
            shiftingMode.setAccessible(true);
            shiftingMode.setBoolean(menuView, false);
            shiftingMode.setAccessible(false);
            for (int i = 0; i < menuView.getChildCount(); i++) {
                BottomNavigationItemView item = (BottomNavigationItemView) menuView.getChildAt(i);
                item.setLabelVisibilityMode(LABEL_VISIBILITY_LABELED);
                // item.setShiftingMode(false);
                // set once again checked value, so view will be updated
                item.setChecked(item.getItemData().isChecked());
            }
        } catch (NoSuchFieldException e) {
            Log.e("ERROR NO SUCH FIELD", "Unable to get shift mode field");
        } catch (IllegalAccessException e) {
            Log.e("ERROR ILLEGAL ALG", "Unable to change value of shift mode");
        }
    }
}



