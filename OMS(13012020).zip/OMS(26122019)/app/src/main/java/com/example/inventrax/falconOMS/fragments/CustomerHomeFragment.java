package com.example.inventrax.falconOMS.fragments;

/*
 * Created by Padmaja on 04/07/2019.
 */

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.inventrax.falconOMS.R;
import com.example.inventrax.falconOMS.activities.MainActivity;
import com.example.inventrax.falconOMS.model.KeyValues;
import com.example.inventrax.falconOMS.room.AppDatabase;
import com.example.inventrax.falconOMS.room.RoomAppDatabase;
import com.example.inventrax.falconOMS.util.FragmentUtils;
import com.example.inventrax.falconOMS.util.SharedPreferencesUtils;

public class CustomerHomeFragment extends Fragment implements View.OnClickListener {

    private static final String classCode = "OMS_Android_CustomerHomeFragment";
    private View rootView;
    private LinearLayout  llOrderBooking, llComplaints,
            llDashboard, llSchemesAndDiscounts;
    SharedPreferencesUtils sharedPreferencesUtils;
    AppDatabase db;
    private String customerId = "",customerName = "",divisionId = "";


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.customer_home_fragment, container, false);
        if(!getArguments().getString("customerId").isEmpty() || getArguments().getString("customerId")!=null) {
            customerId = getArguments().getString("customerId");
            customerName = getArguments().getString("customerName");
            divisionId = getArguments().getString("divisionId");
        }
        loadFormControls();

        return rootView;
    }


    private void loadFormControls() {


        try {

            // To enable Bottom navigation bar
            ((MainActivity) getActivity()).SetNavigationVisibility(true);



            llOrderBooking = (LinearLayout) rootView.findViewById(R.id.llOrderBooking);
            llComplaints = (LinearLayout) rootView.findViewById(R.id.llComplaints);
            llDashboard = (LinearLayout) rootView.findViewById(R.id.llDashboard);
            llSchemesAndDiscounts = (LinearLayout) rootView.findViewById(R.id.llSchemesAndDiscounts);


            llOrderBooking.setOnClickListener(this);
            llComplaints.setOnClickListener(this);
            llDashboard.setOnClickListener(this);
            llSchemesAndDiscounts.setOnClickListener(this);

            db = new RoomAppDatabase(getActivity()).getAppDatabase();

            sharedPreferencesUtils = new SharedPreferencesUtils("LoginActivity", getActivity());
            SharedPreferences sp = getContext().getSharedPreferences(KeyValues.MY_PREFS, Context.MODE_PRIVATE);

        }catch (Exception ex){
            Toast.makeText(getActivity(), ex.getMessage(), Toast.LENGTH_SHORT).show();
        }


    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {


            /*case R.id.llProductCatalog:
                Bundle bundle=new Bundle();
                bundle.putString("customerId",customerId);
                FragmentUtils.replaceFragmentWithBackStackWithBundle(getActivity(), R.id.container, new ProductCatalogFragment(),bundle);
                break;*/

            case R.id.llOrderBooking:
                Bundle bundle=new Bundle();
                bundle.putString("customerId",customerId);
                FragmentUtils.replaceFragmentWithBackStackWithBundle(getActivity(), R.id.container, new ProductCatalogFragment(),bundle);
                break;
            case R.id.llComplaints:
                FragmentUtils.replaceFragmentWithBackStack(getActivity(), R.id.container, new ComplaintsFragment());
                break;
            case R.id.llDashboard:
                FragmentUtils.replaceFragmentWithBackStack(getActivity(), R.id.container, new OrderHistoryFragment());
                break;
            case R.id.llSchemesAndDiscounts:
                bundle=new Bundle();
                bundle.putString("customerId",customerId);
                bundle.putString("divisionId",divisionId);
                FragmentUtils.replaceFragmentWithBackStackWithBundle(getActivity(), R.id.container, new SchemesAndDiscountsFragment(),bundle);
                break;
            case R.id.llOrderTracking:
                FragmentUtils.replaceFragmentWithBackStack(getActivity(), R.id.container, new DeliveryTrackingFragment());
                break;


        }
    }

    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayUseLogoEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle(customerName);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayShowTitleEnabled(true);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}
