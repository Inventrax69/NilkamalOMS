package com.example.inventrax.falconOMS.model;

public enum  OrderStatus {

    COMPLETED,
    ACTIVE,
    INACTIVE,
    PENDING

}
