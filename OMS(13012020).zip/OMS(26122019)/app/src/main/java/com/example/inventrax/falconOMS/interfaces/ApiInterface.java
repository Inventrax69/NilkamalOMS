package com.example.inventrax.falconOMS.interfaces;

/**
 * Author   : Padmaja Rani B.
 * Date		: 04/07/2019
 * Purpose	: Web Service URL's and Web Methods
 */

import com.example.inventrax.falconOMS.pojos.OMSCoreMessage;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Url;

public interface ApiInterface {

    /* @GET("Inventory/GetData")
    Call<String> Get(); */

    @POST("UserLogOut")
    Call<OMSCoreMessage> LoginUser(@Body OMSCoreMessage oRequest);

    @POST("ForgotPassword")
    Call<OMSCoreMessage> ForgotPassword(@Body OMSCoreMessage oRequest);

    @POST("Profile")
    Call<OMSCoreMessage> LoadProfile(@Body OMSCoreMessage oRequest);

    @POST("Changepassword")
    Call<OMSCoreMessage> ChangePassword(@Body OMSCoreMessage oRequest);

    @POST("GetNotifications")
    Call<OMSCoreMessage> GetNotifications(@Body OMSCoreMessage oRequest);

    @POST("Master/ProductCatalog")
    Call<OMSCoreMessage> ProductCatalog(@Body OMSCoreMessage oRequest);

    @POST("Master/GetCustomerList")
    Call<OMSCoreMessage> GetCustomerList(@Body OMSCoreMessage oRequest);

    @POST("Master/GetCustomerListMobile")
    Call<OMSCoreMessage> GetCustomerListMobile(@Body OMSCoreMessage oRequest);

    @POST("Master/SyncItemData")
    Call<OMSCoreMessage> SyncItemData(@Body OMSCoreMessage oRequest);

    @POST("Master/SyncCustomerData")
    Call<OMSCoreMessage> SyncCustomerData(@Body OMSCoreMessage oRequest);

    @POST("OrderAssistanceUpload")
    Call<OMSCoreMessage> OrderAssistanceUpload(@Body OMSCoreMessage oRequest);

    @POST("Orders/cartlist")
    Call<OMSCoreMessage> cartlist(@Body OMSCoreMessage oRequest);

    @POST("Orders/GetPrice")
    Call<OMSCoreMessage> GetPrice(@Body OMSCoreMessage oRequest);

    @POST("Master/VehicleList")
    Call<OMSCoreMessage> VehicleList(@Body OMSCoreMessage oRequest);

    @POST("Orders/HHTCartDetails")
    Call<OMSCoreMessage> HHTCartDetails(@Body OMSCoreMessage oRequest);

    @POST("Orders/OrderFulfilment1")
    Call<OMSCoreMessage> OrderFulfilment(@Body OMSCoreMessage oRequest);

    @POST("Orders/DeleteCartItem")
    Call<OMSCoreMessage> DeleteCartItem(@Body OMSCoreMessage oRequest);

    @POST("Orders/DeleteCartItemReservation")
    Call<OMSCoreMessage> DeleteCartItemReservation(@Body OMSCoreMessage oRequest);

    @POST("Orders/DeleteReservation")
    Call<OMSCoreMessage> DeleteReservation(@Body OMSCoreMessage oRequest);

    @POST("Orders/InitiateWorkflow")
    Call<OMSCoreMessage> InitiateWorkflow(@Body OMSCoreMessage oRequest);

    @POST("Orders/MMIntelliSearch")
    Call<OMSCoreMessage> MMIntelliSearch(@Body OMSCoreMessage oRequest);

    @POST("Orders/InsertCreditLimitCommitments")
    Call<OMSCoreMessage> InsertCreditLimitCommitments(@Body OMSCoreMessage oRequest);

    @POST("Orders/OrderConfirmation")
    Call<OMSCoreMessage> OrderConfirmation(@Body OMSCoreMessage oRequest);

    @POST("Orders/MaterialIntelliSearch")
    Call<OMSCoreMessage> MaterialIntelliSearch(@Body OMSCoreMessage oRequest);

    @POST("Orders/getcart")
    Call<OMSCoreMessage> getcart(@Body OMSCoreMessage oRequest);

    @POST("Orders/ApprovalList")
    Call<OMSCoreMessage> ApprovalList(@Body OMSCoreMessage oRequest);

    @POST("Orders/ApprovalCreditLimitList")
    Call<OMSCoreMessage> ApprovalCreditLimitList(@Body OMSCoreMessage oRequest);

    @POST("Orders/ApprovalDiscount")
    Call<OMSCoreMessage> ApprovalDiscount(@Body OMSCoreMessage oRequest);

    @POST("Orders/ApprovelItemList")
    Call<OMSCoreMessage> ApprovelItemList(@Body OMSCoreMessage oRequest);

    @POST("Orders/ApproveWorkflow")
    Call<OMSCoreMessage> ApproveWorkflow(@Body OMSCoreMessage oRequest);

    @POST("Orders/UpdateApprovalCartList")
    Call<OMSCoreMessage> UpdateApprovalCartList(@Body OMSCoreMessage oRequest);

    @POST("Master/Offers")
    Call<OMSCoreMessage> Offers(@Body OMSCoreMessage oRequest);

    @POST("Master/BulkApproveWorkflow")
    Call<OMSCoreMessage> BulkApproveWorkflow(@Body OMSCoreMessage oRequest);


    /*
    @GET("Master/Image")
    Call<String> Image();
    */

    @POST("Orders/SODependencies")
    Call<OMSCoreMessage> SODependencies(@Body OMSCoreMessage oRequest);

    @POST("Orders/MaterialUnderDivision")
    Call<OMSCoreMessage> MaterialUnderDivision(@Body OMSCoreMessage oRequest);

    @POST("Orders/NHIOrderCreation")
    Call<OMSCoreMessage> NHIOrderCreation(@Body OMSCoreMessage oRequest);

    @POST("Master/Incoterms")
    Call<OMSCoreMessage> Incoterms(@Body OMSCoreMessage oRequest);

    @POST("Master/TermPayment")
    Call<OMSCoreMessage> TermPayment(@Body OMSCoreMessage oRequest);

    @POST("Master/ShiptoPartyCustomer")
    Call<OMSCoreMessage> ShiptoPartyCustomer(@Body OMSCoreMessage oRequest);

    @POST("CustomersunderUser")
    Call<OMSCoreMessage> CustomersunderUser(@Body OMSCoreMessage oRequest);

    @POST("Orders/DeleteItemFromCart")
    Call<OMSCoreMessage> DeleteItemFromCart(@Body OMSCoreMessage oRequest);

    @POST("Orders/LogException")
    Call<String> LogException(@Body OMSCoreMessage oRequest);

    @POST("Orders/GetStock")
    Call<OMSCoreMessage> GetStock(@Body OMSCoreMessage oRequest);

    @GET
    Call<ResponseBody> fetchUrl(@Url String url);

}