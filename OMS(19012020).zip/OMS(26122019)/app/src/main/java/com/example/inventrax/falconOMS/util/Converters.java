package com.example.inventrax.falconOMS.util;

import android.arch.persistence.room.TypeConverter;

import com.example.inventrax.falconOMS.pojos.VariantDTO;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.sql.Date;
import java.util.ArrayList;

public class Converters {
    @TypeConverter
    public static Date fromTimestamp(Long value) {
        return value == null ? null : new Date(value);
    }

    @TypeConverter
    public static Long dateToTimestamp(Date date) {
        return date == null ? null : date.getTime();
    }


    @TypeConverter
    public static Date stringTimeToDate(String value) {
        java.sql.Date ts = java.sql.Date.valueOf(value);
        return ts;
    }


    @TypeConverter
    public static ArrayList<VariantDTO> fromString(String value) {
        Type listType = new TypeToken<ArrayList<VariantDTO>>() {}.getType();
        return new Gson().fromJson(value, listType);
    }

    @TypeConverter
    public static String fromArrayList(ArrayList<VariantDTO> list) {
        Gson gson = new Gson();
        String json = gson.toJson(list);
        return json;
    }
}