package com.example.inventrax.falconOMS.model;

public class KeyValues {

    //Room Database
    public static  String ROOM_DATA_BASE_NAME = "room_oms";

    //SharedPreferences File names
    public static String MY_PREFS="myPrefs";

    // language pref
    public static String SELECTED_LANG="selectedLang";
    public static String SETTINGS_URL="settings_url";

    //SharedPreferences key names
    public static String IS_INTRO_OPENED="isIntroOpnend";
    public static String IS_HINTS="isHints";
    public static String IS_REMEMBER_PASSWORD_CHECKED="isRememberPasswordChecked";
    public static String EMAIL="emailID";
    public static String PASSWORD="password";
    public static String IS_ITEM_LOADED="isItemLoaded";
    public static String IS_CUSTOMER_LOADED ="isCustomerLoaded";
    public static String IS_ITEM_ADDED_TO_CART= "isAdded";
    public static String MODEL_ID= "modelId";
    public static String IS_GRID= "isgrid";
    public static String USER_NAME= "userName";
    public static String CART_HEADERID= "cartHeaderID";
    public static String USER_ID= "userId";
    public static String CUSTOMER_IDS= "customerIDs";
    public static String USER_ROLE_NAME= "user_role_name";
    public static String OPEN_CATALOG= "openCatalog";
    public static String MID= "mID";
    public static String IS_ITEM_MASTER_UPDATE= "isItemMasterUpdate";
    public static String IS_CUSTOMER_MASTER_UPDATE= "isCustomerMasterUpdate";




}
