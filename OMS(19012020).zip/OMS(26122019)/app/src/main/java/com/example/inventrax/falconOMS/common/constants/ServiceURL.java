package com.example.inventrax.falconOMS.common.constants;

/**
 * Created by Padmaja.b on 11/12/2019.
 */

public class ServiceURL {
    private static String serviceUrl;

    public static String getServiceUrl() {
        return serviceUrl;
    }

    public static void setServiceUrl(String serviceUrl) {
        ServiceURL.serviceUrl = serviceUrl;
    }
}
