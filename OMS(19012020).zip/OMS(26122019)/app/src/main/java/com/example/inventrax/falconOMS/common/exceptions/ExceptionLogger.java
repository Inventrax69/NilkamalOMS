package com.example.inventrax.falconOMS.common.exceptions;


public class ExceptionLogger {

    public ExceptionLogger() {
    }

    public ExceptionLogger(String message) {

    }

    public ExceptionLogger(String message, Exception exception) {

    }

    public ExceptionLogger(Exception exception) {

    }


}
