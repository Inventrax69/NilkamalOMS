package com.example.inventrax.falconOMS.common.constants;

public class ErrorMessages {

    public ErrorMessages(){ }

    public String EMC_0001 = "Unable to Connect to the Server.";

    public String EMC_0002 = "Internal Server Error";

    public String EMC_0003 = "Please check the values.";

    public String EMC_0004 = "Server Time out.";

    public String EMC_0005 = "Invalid Credentials.";

    public String EMC_0006 = "Error while loading form controls.";

    public String EMC_0007 = "Please enable Internet.";

    public String EMC_0008 = "Please enter valid email";

    public String EMC_0009 = "Please enter above details";

    public String EMC_0010 = "Please enter valid confirm password";

    public String EMC_0011 = "Please enter old password";

    public String EMC_0012 = "Please enter new password";

    public String EMC_0013 = "Please enter confirm password";

    public String EMC_0014 = "Please check the Internet Connection.";



}
